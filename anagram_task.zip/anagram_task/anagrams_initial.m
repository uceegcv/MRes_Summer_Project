%% Code to display anagram task for LUMO 4-tile array of prefrontal cortex
% Georgina Leadley UCL 2021

% Read in images to display later
H = imread ('green_cross.png');
three_count = imread('countdown_3.png');
two_count = imread('countdown_2.png');
one_count = imread('countdown_1.png');
anagram_instructions = imread('anagram_instructions.png');

% read in image files and assign letter
L = [ 'a','b','c','d','e','f','g','h','i'] ;
p = L(randi(numel(L)));
files1 = dir('anagrams');
names_cell = {files1.name};
files2 = files1;
files2(1) = [];
files = files2;
files(1) = [];
%%

% Shuffle so different array is shown each round
numberOfFiles = length(files);      
randomIndexes = randperm(numberOfFiles);    

% Make a maximized figure with no tool bar and pulldown menus that are along top of figure.
hFig = figure('Toolbar', 'none', 'Menu', 'none', 'WindowState', 'maximized');

% Display task instructions
image(anagram_instructions);
axis('image', 'off');
pause(3);

% Display countdown timer
image(three_count);
axis('image', 'off');
pause(1);
image(two_count);
axis('image', 'off');
pause(1);
image(one_count);
axis('image', 'off');
pause(1);
image(H);
axis('image', 'off');
pause(3);

% Begin timing
tic
for k = 1:numberOfFiles
    while toc < 20                 % loop for each file
        
        % Display random image until user click (how to get around the toc/pause issue?)
        thisFileName = files(k).name;  % Filename of random image
        rgbImage = imread(thisFileName);
        image(rgbImage);
        axis('image', 'off');
        % Wait for user input - is there a better way?
        %pause;
        %w = waitforbuttonpress;
        CH = getkeywait(5);
        
    end
end
toc
% Baseline period
image(H);
axis('image', 'off');
pause(3);
toc

% Close the figure when done
close(hFig);