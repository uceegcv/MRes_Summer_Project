%% Code to display anagram task for LUMO 4-tile array of prefrontal cortex
% Georgina Leadley UCL 2021

% Read in images to display later
H = imread ('green_cross.png');
three_count = imread('countdown_3.png');
two_count = imread('countdown_2.png');
one_count = imread('countdown_1.png');
anagram_instructions = imread('anagram_instructions.png');

% read in image files and assign letter
L = [ 'a','b','c','d','e','f','g','h','i','j','k','l','m','n'] ;
p = L(randi(numel(L)));
files1 = dir('anagrams');
names_cell = {files1.name};
files2 = files1;
files2(1) = [];
files3 = files2;
files3(1) = [];
files = files3;
files(1) = [];
%%

% Shuffle so different array is shown each round
numberOfFiles = length(files);      
randomIndexes = randperm(numberOfFiles);    

% Make a maximized figure with no tool bar and pulldown menus that are along top of figure.
hFig = figure('Toolbar', 'none', 'Menu', 'none', 'WindowState', 'maximized');

% Display task instructions
image(anagram_instructions);
axis('image', 'off');
pause(10);

% Display countdown timer
image(three_count);
axis('image', 'off');
pause(1);
image(two_count);
axis('image', 'off');
pause(1);
image(one_count);
axis('image', 'off');
pause(1);

% Display baseline cross
image(H);
axis('image', 'off');
pause(30);

% Begin timing
tic
k = 1;
num_images_identified = 1;
    while toc < 30                 % loop for each file
        
        % Display random image until user click 
        thisFileName = files(k).name;  % Filename of random image
        rgbImage = imread(thisFileName);
        image(rgbImage);
        axis('image', 'off');
        
        % Wait for user input 
        CH = getkeywait(15);
        
        % Count number of images identified
        num_images_identified = num_images_identified+1;
        
        % Cycle round
        if k < numberOfFiles
            k = k+1;
        else
            k = 1;
        end
    end

toc
% Baseline period
image(H);
axis('image', 'off');
pause(30);

close(hFig);
%%

% Begin timing
tic
k = 1;
num_images_identified = 1;
    while toc < 30                 % loop for each file
        
        % Display random image until user click 
        thisFileName = files(k).name;  % Filename of random image
        rgbImage = imread(thisFileName);
        image(rgbImage);
        axis('image', 'off');
        
        % Wait for user input 
        CH = getkeywait(15);
        
        % Count number of images identified
        num_images_identified = num_images_identified+1;
        
        % Cycle round
        if k < numberOfFiles
            k = k+1;
        else
            k = 1;
        end
    end
    
% Baseline period
image(H);
axis('image', 'off');
pause(30);

% Begin timing
tic
k = 1;
num_images_identified = 1;
    while toc < 30                 % loop for each file
        
        % Display random image until user click 
        thisFileName = files(k).name;  % Filename of random image
        rgbImage = imread(thisFileName);
        image(rgbImage);
        axis('image', 'off');
        
        % Wait for user input 
        CH = getkeywait(15);
        
        % Count number of images identified
        num_images_identified = num_images_identified+1;
        
        % Cycle round
        if k < numberOfFiles
            k = k+1;
        else
            k = 1;
        end
    end
    
% Baseline period
image(H);
axis('image', 'off');
pause(30);

% Begin timing
tic
k = 1;
num_images_identified = 1;
    while toc < 30                 % loop for each file
        
        % Display random image until user click 
        thisFileName = files(k).name;  % Filename of random image
        rgbImage = imread(thisFileName);
        image(rgbImage);
        axis('image', 'off');
        
        % Wait for user input 
        CH = getkeywait(15);
        
        % Count number of images identified
        num_images_identified = num_images_identified+1;
        
        % Cycle round
        if k < numberOfFiles
            k = k+1;
        else
            k = 1;
        end
    end
    
% Baseline period
image(H);
axis('image', 'off');
pause(3);

% Close the figure when done
close(hFig);