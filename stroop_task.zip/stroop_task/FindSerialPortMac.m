
%% Find serial port name and create serial object

disp('Finding serial port...');
info = instrhwinfo('serial');
i = 1; % Counter for serial devices
while i <= length(info.SerialPorts)
    tmp = info.SerialPorts{i};
    if strfind(tmp,'/dev/cu.usb')
        SerialPortName = info.SerialPorts{i};
        break
    end
    i = i + 1;
end
display(['Serial Port Name = ' SerialPortName]);

if exist('sObject','var') == 1 %If already defined, close it.
    if isa(sObject,'serial')
        if strcmpi(sObject.Status,'open')
            fclose(sObject);
        end 
    end
end

sObject = serial(SerialPortName,'BAUD',9600);

%% Example send of serial comman (could be within loop)

%Send the ascii character 'x' down the serial port defined by object sObject:
sObject = SendSerialCommand(sObject,'x');

